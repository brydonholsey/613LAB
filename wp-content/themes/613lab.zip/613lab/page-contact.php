<?php get_header(); ?>

<h1>Hello another yo time, World!</h1>

<?php get_footer(); ?>
